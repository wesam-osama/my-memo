@include('frontend.candidate.applications')
