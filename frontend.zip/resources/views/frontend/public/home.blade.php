@extends('frontend.layouts.public')

@section('title', __('Find your next opportunity') . ' | TalentBridge')

@section('content')
    <section class="hb-container py-20 text-center">
        <h1 class="text-4xl font-semibold tracking-tight text-hb-navy sm:text-5xl">{{ __('Find your next opportunity') }}</h1>
        <p class="mx-auto mt-5 max-w-2xl text-lg text-hb-muted">{{ __('Discover jobs that match your skills and take the next step in your career.') }}</p>
        <div class="mt-8 flex flex-wrap justify-center gap-3">
            <x-button size="lg" :href="route('frontend.jobs.index')">{{ __('Explore jobs') }}</x-button>
            @guest
                <x-button size="lg" variant="secondary" :href="route('frontend.account.register', ['type' => 'candidate'])">{{ __('Create account') }}</x-button>
            @endguest
        </div>
    </section>
@endsection
