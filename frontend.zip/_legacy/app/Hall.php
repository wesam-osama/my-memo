<?php

namespace App\Support;

use Illuminate\Support\Facades\Route;

class Hall
{
    /** 'scene:lobby' -> route('hall.lobby') | 'route:jobs.index' -> route('jobs.index') | '#' if the route does not exist yet */
    public static function url(string $target): string
    {
        [$type, $value] = array_pad(explode(':', $target, 2), 2, null);

        return match ($type) {
            'scene' => Route::has('hall.'.$value) ? route('hall.'.$value) : '#',
            'route' => Route::has($value) ? route($value) : '#',
            default => '#',
        };
    }

    /** true when the target page is built (so the UI can show "soon" for the rest) */
    public static function ready(string $target): bool
    {
        return self::url($target) !== '#';
    }

    public static function active(string $target): bool
    {
        $url = self::url($target);

        return $url !== '#' && request()->url() === $url;
    }
}
