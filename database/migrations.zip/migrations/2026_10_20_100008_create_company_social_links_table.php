<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('company_social_links', function (Blueprint $table) {
            $table->id();
            $table->foreignId('company_id')->constrained('companies')->cascadeOnDelete();
            $table->string('platform');
            $table->string('url', 2048);

             // created_at, updated_at, uid, luid
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('company_social_links');
    }
};
