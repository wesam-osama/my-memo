<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('permissions', function (Blueprint $table) {
            $table->id();
            $table->string('key')->unique();
            $table->text('description')->nullable();

              // created_at, updated_at, uid, luid
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('permissions');
    }
};
